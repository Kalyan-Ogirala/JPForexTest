﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.IO;
using FxPnLCalculator.Models;
using FxPnLCalculator.Controller;

namespace FxPnLCalculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        bool isRatesValid = false;
        bool isTransactionValid = false;
        List<Transaction> transactions;
        List<Rate> rates;
        List<Report> report;

        public MainWindow()
        {
            InitializeComponent();
            btnCalculate.IsEnabled = false;
        }

        private void btnOpenFileRates_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                if (openFileDialog.ShowDialog() == true)
                {
                    txtEditorRate.Text = openFileDialog.FileName;

                    var reader = new StreamReader(File.OpenRead(openFileDialog.FileName));
                    rates = new List<Rate>();
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        string[] values = line.Split(',');

                        Rate currentRate = new Rate();

                        currentRate.BaseCcy = values[0];
                        currentRate.WantedCcy = values[1];
                        currentRate.CcyRate = Convert.ToDecimal(values[2]);
                        currentRate.ValidUntil = Convert.ToDateTime(values[3]);

                        rates.Add(currentRate);
                    }
                }
                isRatesValid = true;
                if (isRatesValid && isTransactionValid)
                    btnCalculate.IsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while loading the file: " + ex.Message, "Error Loading File", MessageBoxButton.OK, MessageBoxImage.Error);
                btnCalculate.IsEnabled = false;
            }
        }

        private void btnOpenFileTrasaction_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                if (openFileDialog.ShowDialog() == true)
                {
                    txtEditorTransaction.Text = openFileDialog.FileName;

                    var reader = new StreamReader(File.OpenRead(openFileDialog.FileName));
                    transactions = new List<Transaction>();
                    report = new List<Report>();
                    int transactionId = 1;
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        string[] values = line.Split(',');
                        if (values[0] == "BaseCurrency" && values[1] == "WantedCurrency" && values[2] == "AmountInBaseCurrency" &&
                            values[3] == "ClientType" && values[4] == "TransactionTime")
                            continue;

                        Transaction currentTransaction = new Transaction();

                        currentTransaction.TransactionId = transactionId;
                        currentTransaction.BaseCcy = values[0];
                        currentTransaction.WantedCcy = values[1];
                        currentTransaction.Amount = Convert.ToUInt32(values[2]) / 100;

                        if (values[3] == "Corporate")
                            currentTransaction.ClientType = ClientType.Corporate;
                        else
                            currentTransaction.ClientType = ClientType.Individual;

                        currentTransaction.TimeOfTx = Convert.ToDateTime(values[4]);

                        transactions.Add(currentTransaction);
                        transactionId++;
                    }
                }

                isTransactionValid = true;
                if (isRatesValid && isTransactionValid)
                    btnCalculate.IsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while loading the file: " + ex.Message, "Error Loading File", MessageBoxButton.OK, MessageBoxImage.Error);
                btnCalculate.IsEnabled = false;
            }
        }

        private void btnCalculate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                IPnLCalculator calculator = new PNLCalculator(rates, transactions);
                List<Report> report = calculator.CalculatePnL();

                IPnLReport reportView = new PnLReport(report);
                reportView.GenerateReport();

                MessageBox.Show("Report Successfully generated ", "Report Geneated", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error during report geneartion: " + ex.Message, "Error Report Geneation", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
