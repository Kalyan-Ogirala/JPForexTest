﻿using FxPnLCalculator.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FxPnLCalculator.Controller
{
    interface IPnLCalculator
    {
        decimal CalculateMarkUp(decimal AmountInUSD, ClientType clientType);
        decimal CalculateActualRate(string baseCcy, string wantedccy, DateTime trxTime, List<Rate> rates);
        decimal CalculateProfit(decimal markupRate, decimal ActualRate, decimal amountInBaseCurrency);
        decimal CalculateFinalRate(Transaction trx, List<Rate> rates);
        decimal CalculateProfitInWantedCurreny();
        decimal CalculateProfitInSGD();
        List<Report> CalculatePnL();
    }
}
