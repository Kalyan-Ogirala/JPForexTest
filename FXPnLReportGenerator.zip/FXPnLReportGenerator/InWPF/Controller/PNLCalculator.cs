﻿using FxPnLCalculator.Controller;
using FxPnLCalculator.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace FxPnLCalculator.Controller
{
    public class PNLCalculator : IPnLCalculator
    {
        public List<Rate> rates;
        public List<Transaction> transactions;        

        //Constructor Dependency Injection
        public PNLCalculator(List<Rate> rates, List<Transaction> transactions)
        {
            this.rates = rates;
            this.transactions = transactions;            
        }        

        public decimal CalculateMarkUp(decimal AmountInUSD, ClientType clientType)
        {
            decimal markUpRate;  
                    
            if (clientType == ClientType.Corporate)
            {
                if (AmountInUSD > 0 && AmountInUSD <= 1000000)
                {
                    markUpRate = 15 / (100);
                } 

                else if (AmountInUSD > 1000000 && AmountInUSD <= 3000000)
                {
                    markUpRate = 10 / (100);
                }
                else
                {
                    markUpRate = 5 / (100);
                }

                return (1 - markUpRate);
            }
            else
            {
                if (AmountInUSD > 0 && AmountInUSD <= 8000)
                {
                    markUpRate = 40 / (100);
                }

                else if (AmountInUSD > 8000 && AmountInUSD <= 20000)
                {
                    markUpRate = 35 / (100);
                }
                else if (AmountInUSD > 20000 && AmountInUSD <= 35000)
                {
                    markUpRate = 30 / (100);
                }
                else
                {
                    markUpRate = 25 / (100);
                }

                return markUpRate;
            }
        }

        public decimal CalculateActualRate(string baseCcy, string wantedccy, DateTime trxTime, List<Rate> rates) 
        {                       
           List<Rate> requiredRates = rates.Where(x => x.BaseCcy == baseCcy && x.WantedCcy == wantedccy).OrderBy(x=>x.ValidUntil).ToList();
           foreach(Rate newRate in requiredRates)
            {
                if (newRate.ValidUntil > trxTime)
                {
                    return newRate.CcyRate;
                }                
            }

            return 0;
        }

        public decimal CalculateProfit(decimal markupRate, decimal ActualRate, decimal amountInBaseCurrency)
        {
            return (1-markupRate) * ActualRate * amountInBaseCurrency;
        }

        public decimal CalculateFinalRate(Transaction trx, List<Rate> rates)
        {
            return (CalculateActualRate(trx.BaseCcy, trx.WantedCcy, trx.TimeOfTx, rates) * (1 - CalculateMarkUp(trx.Amount, trx.ClientType)));
        }

        public decimal CalculateProfitInWantedCurreny()
        {
            //No Time - Time constraint
            return 1;
        }

        public decimal CalculateProfitInSGD()
        {
            //No Time - Time constraint
            return 1;
        }

        public List<Report> CalculatePnL()
        {
            List<Report> report = new List<Report>();           
            foreach (Transaction trans in transactions)
            {
                Report rpt = new Report();
                rpt.BaseCurrency = trans.BaseCcy;
                rpt.WantedCurrency = trans.WantedCcy;
                rpt.AmountInBaseCurrency = Convert.ToString(trans.Amount);
                rpt.StandardRate = Convert.ToString(CalculateActualRate(trans.BaseCcy, trans.WantedCcy, trans.TimeOfTx, rates));
                rpt.FinalRate = Convert.ToString(CalculateFinalRate(trans, rates));
                rpt.ProfitInWantedCurrency = "";
                rpt.ProfitInSGD = "";

                report.Add(rpt);
            }

            return report;
        }
    }

    
}
