﻿using FxPnLCalculator.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FxPnLCalculator.Controller
{
    public class PnLReport : IPnLReport
    {
        List<Report> finalReport;

        //Constructor Dependency Injection
        public PnLReport(List<Report> report)
        {
            this.finalReport = report;
        }

        public void GenerateReport()
        {
            var newReportRow = new StringBuilder();
            foreach (Report rpt in finalReport)
            {
              var newLine = string.Format("{0},{1},{2},{3},{4},TBC,TBC", rpt.BaseCurrency, rpt.WantedCurrency, rpt.AmountInBaseCurrency, 
                    rpt.StandardRate, rpt.FinalRate, rpt.ProfitInWantedCurrency, rpt.ProfitInSGD);
                newReportRow.AppendLine(newLine);
            }

            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            dlg.FileName = "FxCalculatorReport"; 
            dlg.DefaultExt = ".csv"; 
            dlg.Filter = "CSV Files (*.csv)|*.csv"; 

            Nullable<bool> result = dlg.ShowDialog();
                        
            if (result == true)
            {               
                File.WriteAllText(dlg.FileName, newReportRow.ToString());
            }            
        }
    }
}
