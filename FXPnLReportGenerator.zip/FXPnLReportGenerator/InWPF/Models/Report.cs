﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FxPnLCalculator.Models
{
    public class Report
    {        
        public string BaseCurrency { get; set; }
        public string WantedCurrency { get; set; }
        public string AmountInBaseCurrency { get; set; }
        public string StandardRate { get; set; }
        public string FinalRate { get; set; }
        public string ProfitInWantedCurrency { get; set; }
        public string ProfitInSGD { get; set; }        
    }
}
