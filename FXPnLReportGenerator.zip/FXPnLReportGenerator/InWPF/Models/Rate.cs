﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FxPnLCalculator.Models
{
    public class Rate
    {
        public int Id { get; set; }
        public string BaseCcy { get; set; }
        public string WantedCcy { get; set; }
        public decimal CcyRate { get; set; }
        public DateTime ValidUntil { get; set; }
    }
}
