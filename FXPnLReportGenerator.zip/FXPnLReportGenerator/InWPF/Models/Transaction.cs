﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FxPnLCalculator.Models
{
    public class Transaction
    {
        public int TransactionId { get; set; }
        public string BaseCcy { get; set; }
        public string WantedCcy { get; set; }
        public decimal Amount { get; set; }
        public ClientType ClientType { get; set; }
        public DateTime TimeOfTx { get; set; }
    }

    public enum ClientType { Individual, Corporate }
}
