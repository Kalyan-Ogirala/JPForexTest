﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FxPnLCalculator.Controller;
using FxPnLCalculator.Models;
using Moq;
using FluentAssertions;

namespace FxPnLCalculator.UnitTests
{
    [TestClass]
    public class PnLCalculatorTest
    {
        [TestMethod]
        public void CalculateMarkUp()
        {
            Mock<List<Rate>> mockRates = new Mock<List<Rate>>();
            Mock<List<Transaction>> mockTransactions = new Mock<List<Transaction>>();
            var pnlCalculator = new PNLCalculator(mockRates.Object, mockTransactions.Object);
            pnlCalculator.Should().NotBeNull();
            pnlCalculator.CalculateMarkUp(5000, ClientType.Individual).Should().ShouldBeEquivalentTo("0.4");
        }

        //Repeat Similar test for the below methods - Time Constraint

        [TestMethod]
        public void CalculateActualRate()
        {           
        }

        [TestMethod]
        public void CalculateProfit()
        {
        }

        [TestMethod]
        public void CalculateFinalRate()
        {
        }

        [TestMethod]
        public void CalculateProfitInWantedCurreny()
        {
        }

        [TestMethod]
        public void CalculateProfitInSGD()
        {
        }

        [TestMethod]
        public void CalculatePnL()
        {
        }
    }
}
